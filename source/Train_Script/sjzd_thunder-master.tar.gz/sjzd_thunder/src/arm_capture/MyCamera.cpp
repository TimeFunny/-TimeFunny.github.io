#include "MyCamera.h"


MyCamera::MyCamera()
{
	
}
MyCamera::~MyCamera()
{
	
}

short MyCamera::getIndex()
{
	return index_;
}

void  MyCamera::setIndex(short index)
{
	index_ = index;
}







