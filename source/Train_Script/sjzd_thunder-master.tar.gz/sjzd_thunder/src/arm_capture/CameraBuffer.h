#ifndef SJZD_CAMERA_BUFFER
#define SJZD_CAMERA_BUFFER

#include "MyCamera.h"

class CameraBuffer{
public:
	CameraBuffer(MyCamera* pCamera);
	~CameraBuffer();
	
public:
	void addImgBuffer(ImageBuffer* pImgBuffer);
	void preDetect();
	void detect();
	void printQueInfo();
private:
	MyCamera*                       pCamera_;
	MutexLock			            queBufLock_;
	deque<ImageBuffer*>             queImgBuffers_;
	//volatile unsigned int			queImgBufSize_;

	
	MutexLock			            queThunderImgLock_;
	deque<ImageBuffer*>             queThunderImg_;
	//volatile unsigned int			queThunderImgBufSize_;
	
};

typedef map<MyCamera*,CameraBuffer*> MAP_CAMERA_BUFFER;

#endif
