
#include "MutexLock.h"

MutexLock::MutexLock()
{
     destoryed_ = false;
	 pthread_mutex_init(&mutex_, NULL);
}

MutexLock::~MutexLock()
{
	destory();
}


void MutexLock::lock()
{
	pthread_mutex_lock(&mutex_);
}


void MutexLock::unlock()
{
	 pthread_mutex_unlock(&mutex_);
}

void MutexLock::destory()
{
	if(!destoryed_)
	{
		pthread_mutex_destroy(&mutex_);
	}
	destoryed_ = true;
}


AutoLock::AutoLock(MutexLock* lock)
	:lock_(lock)
{
	lock_->lock();
}

AutoLock::~AutoLock()
{
	lock_->unlock();
}

