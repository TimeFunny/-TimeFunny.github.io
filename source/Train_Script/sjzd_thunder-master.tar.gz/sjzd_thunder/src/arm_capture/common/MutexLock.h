#ifndef SJZD_MUTEX_LOCK
#define SJZD_MUTEX_LOCK

#include <pthread.h>


class MutexLock{
public:
	MutexLock();
	virtual ~MutexLock();
	
public:
	void lock();
	void unlock();
	
private:
	void destory();

	
private:
	pthread_mutex_t  mutex_;
	bool			 destoryed_;
};

class AutoLock
{
public:
	AutoLock(MutexLock* lock);
	virtual ~AutoLock();

private:
	MutexLock* lock_;
};

#endif

