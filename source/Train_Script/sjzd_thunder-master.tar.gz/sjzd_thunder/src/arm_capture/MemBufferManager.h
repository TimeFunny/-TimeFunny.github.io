#ifndef SJZD_MEM_BUFFER_MANAGER
#define SJZD_MEM_BUFFER_MANAGER

#include "Thunder_Define.h"
#include "common/MutexLock.h"
#include "common/Singleton.h"


template<class T>
class MEM_BUF_MANAGER
{
public:
	MEM_BUF_MANAGER();
	virtual ~MEM_BUF_MANAGER();

	
public:
	T* 		getBuffer();
	void	freeBuffer(T* pBuf);
	int 	getBufferCount();
	int	    getAllocCount();
	int 	getReleaseCount();

	
public:
	
	MutexLock 				     lock_;
	std::list<T*>				 listBufs_;
	int							 nGetBufferCount_;
	int							 nReleaseBufferCount_;
};



template<class T>
MEM_BUF_MANAGER<T>::MEM_BUF_MANAGER()
{
    nGetBufferCount_ = 0;
	nReleaseBufferCount_ = 0;
}

template<class T>
MEM_BUF_MANAGER<T>::~MEM_BUF_MANAGER()
{
	
    AutoLock safelock(&lock_);

    typename std::list<T*>::iterator iter = listBufs_.begin();;
	
    for(;iter != listBufs_.end();iter++)
    {
        T* pTmp = (T*)*iter;
        if(pTmp != NULL)
        {
            delete pTmp;
            pTmp = NULL;
        }
    }
	
    listBufs_.clear();
}

template<class T>
T* MEM_BUF_MANAGER<T>::getBuffer()
{
	AutoLock safelock(&lock_);

    T* pPDBuf = NULL;
    {
        typename std::list<T*>::iterator iter = listBufs_.begin();
        if(iter != listBufs_.end())
        {
            pPDBuf = *iter;
            listBufs_.erase(iter);
        }
    }
    
    if(NULL == pPDBuf)
    {
        pPDBuf = new T;
    }
    nGetBufferCount_ ++;
	if(nGetBufferCount_ == SJ_INT_MAX_VALUE)
	{
		nGetBufferCount_ = 0;
	}
    return pPDBuf;
}

template<class T>
void MEM_BUF_MANAGER<T>::freeBuffer(T* pBuf)
{
    if(NULL == pBuf)
    {
        return;
    }
	
    {
    	AutoLock safelock(&lock_);
	    listBufs_.push_back(pBuf);
    }
    
	nReleaseBufferCount_++;
	if(nReleaseBufferCount_ == SJ_INT_MAX_VALUE)
	{
		nReleaseBufferCount_ = 0;
	}
}

template<class T>
int  MEM_BUF_MANAGER<T>::getBufferCount()
{
    AutoLock safelock(&lock_);

    return (int)listBufs_.size();
}

template<class T>
int  MEM_BUF_MANAGER<T>::getAllocCount()
{
	return nGetBufferCount_;
}

template<class T>
int  MEM_BUF_MANAGER<T>::getReleaseCount()
{
	return nReleaseBufferCount_;
}


//typedef   common::Singleton<MEM_BUF_MANAGER>      SingletonMemBufferManager;
//typedef   SingletonMemBufferManager::instance()   SingletonMemBufferManager_Instance;


#endif

