#include <stdio.h>
#include "version_config.h"
#include "ConfigFile.h"
#include "Application.h"
#include <signal.h>




void sigFunc(int sigId)
{
	//IM::gtoStop = 1;
	g_Stop = 1;
}

void setSignal()
{
	// signal(SIGINT,  SIG_IGN);
	signal(SIGINT,  sigFunc);//ctrl+c
	signal(SIGTERM, sigFunc);
	signal(SIGCHLD, SIG_IGN);
	signal(SIGPIPE, SIG_IGN);
	signal(SIGTTOU, SIG_IGN);
	signal(SIGTSTP, SIG_IGN);
	signal(SIGHUP,  SIG_IGN);
}



int main(int argc, char* argv[])
{
	//=======show version
	if (argc == 2)
	{
		if (memcmp(argv[1], "-v", 2) == 0 || memcmp(argv[1], "--version", 9) == 0)
		{
			fprintf(stderr, "sjzd_thunder version: %s\n", Tutorial_VERSION_MAJOR);
		}
		else
		{
			fprintf(stderr, "Usage: ./sjzd_thunder -v\n");
			fprintf(stderr, "		./sjzd_thunder --version\n");
		}
		return 0;
	}
	//=======show version
	

	setSignal();

	
	if (SingletonApplication::instance().init() < 0)
	{
		fprintf(stderr, "program init error\n");
		exit(0);
	}
	
	SingletonApplication::instance().run();
	
	return 0;
}
