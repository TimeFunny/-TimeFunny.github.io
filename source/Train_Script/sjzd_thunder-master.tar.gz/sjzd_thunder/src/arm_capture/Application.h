#ifndef SJZD_THUNDER_APPLICATION
#define SJZD_THUNDER_APPLICATION

#include "Thunder_Define.h"
#include "common/Singleton.h"
#include "common/MutexLock.h"

#include "ImgBuffer.h"
#include "CameraBuffer.h"

// 初始化类
class Application
{
public:
	Application();
	virtual ~Application();
	
public:
	int init();
	int run();
	
private:
	bool createWorkThread();
	void initMapCameraBuf();
	void printMemeInfo();
private:
	//const char* configFile_;
	pthread_t              threadCapture_,threadPreDetect_,threadPersist_;
	
public:
	/*
	MutexLock			   imgBufLock_;
	
	list<ImageBuffer*>     listImgBuf_;
	volatile int           listSize_;
	*/
	MAP_CAMERA_BUFFER   mapCameraBuf_;
	
};
typedef   common::Singleton<Application>      SingletonApplication;

extern volatile int g_Stop;


#endif
