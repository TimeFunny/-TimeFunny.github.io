#ifndef SJZD_THUNDER_DEFINE
#define SJZD_THUNDER_DEFINE

#include <hkvision/ca/MvCameraControl.h>

#include <string>
#include <vector>
#include <list>
#include <map>
#include <deque>
#include <spdlog/spdlog.h>
#include <spdlog/sinks/basic_file_sink.h>
#include "spdlog/sinks/rotating_file_sink.h" // support for rotating file logging


#define   SJ_INT_MAX_VALUE      2147483647
#define   SJ_INT64_MAX_VALUE    4294967295

#define   SJ_MAX_PAY_LOAD_SIZE    1800*1400*4


using namespace std;

#endif

