#include "CameraBuffer.h"
#include "ConfigFile.h"
#include <cmath>
#include "ImgBuffer.h"


CameraBuffer::CameraBuffer(MyCamera* pCamera)
	:pCamera_(pCamera)
{
	//queImgBufSize_        = 0;
	//queThunderImgBufSize_ = 0;
}

CameraBuffer::~CameraBuffer()
{

}

void CameraBuffer::addImgBuffer(ImageBuffer* pImgBuffer)
{
	
	AutoLock lock(&queBufLock_);
	queImgBuffers_.push_back(pImgBuffer);

	//queImgBufSize_++;
		
}

void CameraBuffer::preDetect()
{
	AutoLock lock(&queBufLock_);
	const unsigned int detectImgNUm = SingletonConfigFile::instance().preDetectQueSize_;
	if(queImgBuffers_.size() <= detectImgNUm)
	{
		return;
	}
	
	unsigned int           index          = 0;
	
	ImageBuffer*    pKeybuf           = nullptr;
	unsigned int    totalBright    = 0;
	unsigned int    curBright      = 0;
	
	{
		
		pKeybuf = queImgBuffers_[detectImgNUm];
		if(nullptr == pKeybuf)
		{
			return;
		}
		curBright = pKeybuf->attribute_.averageBrightness_;
		
		auto iter = queImgBuffers_.begin();
		for(;iter != queImgBuffers_.end();iter++,index++)
		{
			if((*iter) == nullptr)
			{
				continue;
			}
			if(index >= detectImgNUm)
			{
				break;
			}
			
			totalBright += (*iter)->attribute_.averageBrightness_;
		}

		spdlog::info("======bright compare a:{} curbright:{}=========",
				totalBright/detectImgNUm,
				curBright);

		if(abs((int)(totalBright/detectImgNUm - curBright)) >= SingletonConfigFile::instance().brightDetectThreshold_)
		{
			spdlog::info("======detect bright exception=========");
			//可能为雷电图片
			queImgBuffers_.erase(queImgBuffers_.begin() + detectImgNUm);
			
			AutoLock lock(&queThunderImgLock_);
			queThunderImg_.push_back(pKeybuf);
			//queThunderImgBufSize_++;
		}
		
		{
			//将第一个元素回收到内存池
			auto iterBegin = queImgBuffers_.begin();
			ImgBufferManager::instance().freeBuffer((*iterBegin));
			queImgBuffers_.erase(iterBegin);
			//queImgBufSize_--;
		}
		
	}	
}




void CameraBuffer::detect()
{
	
	AutoLock lock(&queThunderImgLock_);
	if(queThunderImg_.size() <= 0)
	{
		return;
	}
	auto iter = queThunderImg_.begin();
	for(;iter != queThunderImg_.end();iter++)
	{
		if((*iter) == nullptr)
		{
			continue;
		}

		//在这里监测是否为闪电图片
		//
		ImgBufferManager::instance().freeBuffer((*iter));
	}
	queThunderImg_.clear();	
}

void CameraBuffer::printQueInfo()
{
	spdlog::info("camera:{} queBufSize:{} thunderBufSize:{}",
			pCamera_->getIndex(),
			queImgBuffers_.size(),
			queThunderImg_.size());
}



