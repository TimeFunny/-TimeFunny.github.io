#include "CameraManager.h"
#include "ConfigFile.h"
#include "HikCACamera.h"


CameraManager::CameraManager()
{

}

CameraManager::~CameraManager()
{
	
}

void CameraManager::uninit()
{
	clearCameras();
}

void CameraManager::copyCameras(vector<MyCamera*>& vecCameras)
{
	vecCameras = vecCamera_;
}



bool CameraManager::init()
{
	spdlog::info("CameraManager::init begin");
	if(!checkDevices())
	{
		spdlog::error("CameraManager::init checkDevices failed");
		return false;
	}
	spdlog::info("CameraManager::init end");
	return true;
}

bool CameraManager::openCameras()
{
	spdlog::info("CameraManager::openCamera begin");

	auto size = vecCamera_.size();
	for(unsigned int  i = 0;i < size;i++)
	{
		MyCamera* pCamera = vecCamera_[i];
		if(nullptr == pCamera)
		{
			continue;
		}
		if(!pCamera->openDevice())
		{
			return false;
			spdlog::error("camera open failed");	
			continue;
		}
		spdlog::info("camera open success");
	}
	spdlog::info("CameraManager::openCamera end");
	return true;
}

bool CameraManager::startGrabbing()
{
	spdlog::info("CameraManager::startGrabbing begin");

	auto size = vecCamera_.size();
	for(unsigned int  i = 0;i < size;i++)
	{
		MyCamera* pCamera = vecCamera_[i];
		if(nullptr == pCamera)
		{
			continue;
		}
		if(!pCamera->startGrabbing())
		{
			return false;
			spdlog::error("camera grabbing failed");	
			continue;
		}
	}
	spdlog::info("CameraManager::startGrabbing end");
	return true;
}

bool CameraManager::stopGrabbing()
{
	spdlog::info("CameraManager::stopGrabbing begin");

	auto size = vecCamera_.size();
	for(unsigned int  i = 0;i < size;i++)
	{
		MyCamera* pCamera = vecCamera_[i];
		if(nullptr == pCamera)
		{
			continue;
		}
		if(!pCamera->stopGrabbing())
		{
			spdlog::error("camera stop grabbing failed");	
			continue;
		}
	}
	spdlog::info("CameraManager::stopGrabbing end");
	return true;
}

bool CameraManager::closeCameras()
{
	spdlog::info("CameraManager::closeCameras begin");
	auto size = vecCamera_.size();
	for(unsigned int  i = 0;i < size;i++)
	{
		MyCamera* pCamera = vecCamera_[i];
		if(nullptr == pCamera)
		{
			continue;
		}
		pCamera->closeDevice();
	}
	//vecCamera_.clear();
	spdlog::info("CameraManager::closeCameras end");
	return true;
}



bool CameraManager::checkDevices()
{

	string& type = SingletonConfigFile::instance().cameraType_;
	spdlog::info("CameraManager::init cameratype:{0}",type);
	if(type == "usb_hikvision")
	{
		if(false == initHikVisionDevices())
		{
			return false;
		}
		
	}

	return true;
}


bool CameraManager::initHikVisionDevices()
{
	spdlog::info("initHikVisionDevices::init begin====");

	//usb hikvision
	MV_CC_DEVICE_INFO_LIST stDeviceList;
	memset(&stDeviceList, 0, sizeof(MV_CC_DEVICE_INFO_LIST));
	
	if(MV_OK != HikCACamera::enumDevices(&stDeviceList))
	{
		return false;
	}

	if (stDeviceList.nDeviceNum <= 0)
	{
		return false;
	}

	//==========create cameras
	for (unsigned int i = 0; i < stDeviceList.nDeviceNum; i++)
	{

		MV_CC_DEVICE_INFO* pDeviceInfo = stDeviceList.pDeviceInfo[i];
		if (NULL == pDeviceInfo)
		{
			break;
		}
		MyCamera* pCamera = new HikCACamera(pDeviceInfo);
		if(nullptr == pCamera)
		{
			return false;
		}
		pCamera->setIndex((short)i);
		vecCamera_.push_back(pCamera);
	}  
	//==========create cameras
	return true;
	spdlog::info("initHikVisionDevices::init end====");
}

void CameraManager::clearCameras()
{
	spdlog::info("CameraManager::clearCameras begin");
	/*
	auto size = vecCamera_.size();
	for(unsigned int  i = 0;i < size;i++)
	{
		MyCamera* pCamera = vecCamera_[i];
		if(nullptr == pCamera)
		{
			continue;
		}
		delete pCamera;
		pCamera = nullptr;
	}
	vecCamera_.clear();
	*/
	spdlog::info("CameraManager::clearCameras end");
}



