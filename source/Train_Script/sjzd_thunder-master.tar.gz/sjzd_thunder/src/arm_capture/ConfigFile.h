#ifndef SJZD_THUNDER_CONFIG_FILE
#define SJZD_THUNDER_CONFIG_FILE

#include "common/tinyxml2.h"
#include "common/Singleton.h"
#include <string>

using namespace std;
using namespace tinyxml2;

class ConfigFile{
public:
	ConfigFile();
	virtual ~ConfigFile();
	
public:
	bool readConfig();

private:
	void loadXml();
	void loadXmlStr(XMLElement* pNode,const char* nodeName,string& outVal);
	void loadXmlInt(XMLElement* ppNode,const char* nodeName,int& outVal);
	void loadXmlShort(XMLElement* ppNode,const char* nodeName,short& outVal);
public:
	string       fileName_;
	
	string       workMode_;
	short		 photoUpdateInter_;
	string       devicecId_;
	short		 cameraNum_;
	string       cameraType_;
	short        preDetectQueSize_;
	short        getFrameTimeout_;//获取帧超时时间
	short		 brightDetectThreshold_;        
};
typedef   common::Singleton<ConfigFile>      SingletonConfigFile;
#endif