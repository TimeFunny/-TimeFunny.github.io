
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include "Application.h"
#include "ConfigFile.h"
#include <pthread.h>

#include "CameraManager.h"
#include "common/DirUtil.h"
#include "MemBufferManager.h"
#include "ImgBuffer.h"


volatile int g_Stop = 0;
MutexLock Alock_;


Application::Application()
{
	threadCapture_ = threadPreDetect_ = threadPersist_ = 0;
	//listSize_ = 0;
}

Application::~Application() 
{
	SingletonCameraManager::instance().uninit();
}

int Application::init()
{
	//=================spdlog
	//const char* plogPath = "./logs";
	const char* plogFile = "./logs/log.txt";
	
	string exePath = DirUtil::GetExePath();
	exePath += "/logs";

	if(0 != DirUtil::MakeDir(exePath))
	{
		fprintf(stderr, "mkdir error failed(%s)\n",strerror(errno));
		//_LOG_LAST_ERROR("mkdir %s failed(%s)", path.c_str(), strerror(errno));
		return -1;
	}
	
	/*
	if (mkdir(plogPath, 0777) != 0)
	{
		fprintf(stderr, "mkdir error failed(%s)\n",strerror(errno));
		//_LOG_LAST_ERROR("mkdir %s failed(%s)", path.c_str(), strerror(errno));
		return -1;
	}
	*/
	
	spdlog::set_level(spdlog::level::debug); // Set global log level to debug
	// Set the default logger to file logger
    auto file_logger = spdlog::rotating_logger_mt("basic_logger", plogFile, 1024 * 1024 * 5, 3);
	// create a file rotating logger with 5mb size max and 3 rotated files
	//auto file_logger = spdlog::rotating_logger_mt("file_logger", "myfilename", 1024 * 1024 * 5, 3);
    spdlog::set_default_logger(file_logger);    
	spdlog::flush_every(std::chrono::seconds(1));

	spdlog::info("Application init!");
	//=================spdlog

	bool bRet = true;
	do
	{
		bRet = SingletonConfigFile::instance().readConfig();
		if(!bRet)
		{
			break;
		}

		bRet = SingletonCameraManager::instance().init();
		if(!bRet)
		{
			break;
		}

		bRet = SingletonCameraManager::instance().openCameras();
		if(!bRet)
		{
			break;
		}		

		bRet = SingletonCameraManager::instance().startGrabbing();
		if(!bRet)
		{
			break;
		}	

		initMapCameraBuf();

		createWorkThread();
	}while(0);
		
	return bRet;
}



int Application::run()
{
	// 启动LoginServer服务
	//INFO_LOG("启动LoginServer服务...");
	//LoginServer::instance().start();
	//INFO_LOG("启动LoginServer服务成功");
	
	while (1)
	{
		if (g_Stop == 1)
		{
			/*
			// 将程序设置为后台模式(Daemon)
			if (g_flag_deamon)
				Daemon::DaemonProcess("stop", config_->getPidFile().c_str());
			break;
			*/
			spdlog::info("Application ready to stop.");
			//wait for thread exit

			pthread_join(threadCapture_,NULL);
			pthread_join(threadPreDetect_,NULL);
			pthread_join(threadPersist_,NULL);
			
			SingletonCameraManager::instance().stopGrabbing();
			SingletonCameraManager::instance().closeCameras();
			SingletonCameraManager::instance().uninit();
			break;
		}

		printMemeInfo();
		sleep(3);
	}
	return 0;
}


void Application::printMemeInfo()
{
	spdlog::info("buffer:{0}  alloc:{1}  free:{2}  "
			,ImgBufferManager::instance().getBufferCount()
			,ImgBufferManager::instance().getAllocCount()
			,ImgBufferManager::instance().getReleaseCount());

	MAP_CAMERA_BUFFER& mapCameraBuf = SingletonApplication::instance().mapCameraBuf_;
	for(auto iter = mapCameraBuf.begin();iter != mapCameraBuf.end();iter++)
	{
		
		iter->second->printQueInfo();
	}
}



static void* captureThread(void* pUser)
{
	/*
	{
		AutoLock lock(&Alock_); 
		spdlog::info("captureThread begin ======");
		sleep(5);
		spdlog::info("captureThread end ======");
	}
	*/
	


	MAP_CAMERA_BUFFER& mapCameraBuf = SingletonApplication::instance().mapCameraBuf_;
	while(1)
	{
		if (g_Stop == 1)
		{
			break;
		}

		for(auto iter = mapCameraBuf.begin();iter != mapCameraBuf.end();iter++)
		{
			ImageBuffer* imgBuffer = nullptr;
			if(!iter->first->getOneFrame(imgBuffer))
			{
				spdlog::error("getOneFrame error!!!");
				continue;
			}
			if(imgBuffer == nullptr)
			{
				continue;
			}
			iter->second->addImgBuffer(imgBuffer);
		}
		
		//sleep(1);
	}
	spdlog::info("captureThread  stoped.");
	return nullptr;
}

static void* preDetectThread(void* pUser)
{
	/*
	{
		sleep(2);
		AutoLock lock(&Alock_); 
		spdlog::info("preDetectThread begin ======");
		sleep(5);
		spdlog::info("preDetectThread end ======");
	}
	*/

	MAP_CAMERA_BUFFER& mapCameraBuf = SingletonApplication::instance().mapCameraBuf_;
	while(1)
	{
		if (g_Stop == 1)
		{
			break;
		}
		for(auto iter = mapCameraBuf.begin();iter != mapCameraBuf.end();iter++)
		{
			if(iter->second == nullptr)
			{
				continue;
			}
			iter->second->preDetect();
		}
		//sleep(1);
	}

	spdlog::info("preDetectThread  stoped.");

	return nullptr;
}

static void* persistThread(void* pUser)
{
	MAP_CAMERA_BUFFER& mapCameraBuf = SingletonApplication::instance().mapCameraBuf_;
	while(1)
	{
		if (g_Stop == 1)
		{
			break;
		}
		for(auto iter = mapCameraBuf.begin();iter != mapCameraBuf.end();iter++)
		{
			if(iter->second == nullptr)
			{
				continue;
			}
			iter->second->detect();
		}
		sleep(1);
	}

	spdlog::info("persistThread  stoped.");
	return nullptr;
}


bool Application::createWorkThread()
{
	int nRet = pthread_create(&threadCapture_, NULL ,captureThread , this);
	if(nRet != 0)
	{
		return false;
	}
	
	nRet = pthread_create(&threadPreDetect_, NULL ,preDetectThread , this);
	if(nRet != 0)
	{
		return false;
	}
	
	nRet = pthread_create(&threadPersist_, NULL ,persistThread , this);
	if(nRet != 0)
	{
		return false;
	}
	return true;	
}


void Application::initMapCameraBuf()
{
	//暂不考虑摄像机中途被拔掉的情况
	vector<MyCamera*> cameras ;
	SingletonCameraManager::instance().copyCameras(cameras);
	spdlog::info("captureThread  camera count:{0}",cameras.size());

	MAP_CAMERA_BUFFER& mapCameraBuf = SingletonApplication::instance().mapCameraBuf_;

	//
	auto size = cameras.size();
	for(unsigned int  i = 0;i < size;i++)
	{
		MyCamera* pCamera = cameras[i];
		if(nullptr == pCamera)
		{
			continue;
		}
		CameraBuffer* pCameraBuffer = new CameraBuffer(pCamera);
		if(nullptr == pCameraBuffer)
		{
			continue;
		}
		mapCameraBuf[pCamera] = pCameraBuffer;
		
	}
}


