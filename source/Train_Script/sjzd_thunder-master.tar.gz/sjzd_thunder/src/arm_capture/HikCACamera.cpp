#include "HikCACamera.h"

HikCACamera::HikCACamera(MV_CC_DEVICE_INFO*      pDeviceInfo)
{
	pDeviceInfo_     =   pDeviceInfo;
	pDeviceHandle_   =   nullptr;
	payloadSize_     =   0;
}

HikCACamera::~HikCACamera()
{
	if(nullptr != pDeviceHandle_ )
	{
		closeDevice();	
	}
}


int HikCACamera::enumDevices(MV_CC_DEVICE_INFO_LIST* pstDevList)
{
	if(nullptr == pstDevList)
	{
		return MV_E_UNKNOW;
	}
	
	int nRet = MV_CC_EnumDevices(MV_GIGE_DEVICE | MV_USB_DEVICE, pstDevList);

	if (MV_OK != nRet)
    {
    	spdlog::error("MV_CC_EnumDevices failed 0x{0:x}",(uint32_t)nRet );		
        return nRet;
    }

    return MV_OK;
}

bool HikCACamera::openDevice()
{
	if(nullptr == pDeviceInfo_)
	{
		return false;
	}
	
	int nRet = MV_OK;

    // select device and create handle
    nRet = MV_CC_CreateHandle(&pDeviceHandle_, pDeviceInfo_);
    if (MV_OK != nRet)
    {
        spdlog::error("MV_CC_CreateHandle failed 0x{0:x}",(uint32_t)nRet );		
        return nRet;
    }

	


    // 打开设备
    // open device
    nRet = MV_CC_OpenDevice(pDeviceHandle_);
    if (MV_OK != nRet)
    {
        spdlog::error("MV_CC_OpenDevice failed 0x{0:x}",(uint32_t)nRet );		
        return nRet;
    }
	
	if(!initBrightness())
	{
		return false;
	}

	return (MV_OK == nRet);
}

bool HikCACamera::startGrabbing()
{
	if(nullptr == pDeviceHandle_)
	{
		return false;
	}
	
	int nret = MV_CC_StartGrabbing(pDeviceHandle_);
	if(nret != MV_OK)
	{
		spdlog::error("start grabbing failed 0x{0:x}",(uint32_t)nret);		
		return false;
	}

	if(!initPayloadSize())
	{
		return false;
	}
	
	
	return  (MV_OK == nret);
}

bool HikCACamera::initPayloadSize()
{
	if(nullptr == pDeviceHandle_)
	{
		return false;
	}

	
	// ch:获取数据包大小 | en:Get payload size
    MVCC_INTVALUE stParam;
    memset(&stParam, 0, sizeof(MVCC_INTVALUE));
    int  nret = MV_CC_GetIntValue(pDeviceHandle_, "PayloadSize", &stParam);
	
	payloadSize_ = stParam.nCurValue;

	spdlog::info("Current payload size: {0}", payloadSize_);
    if (MV_OK != nret)
    {
        spdlog::error("Get PayloadSize fail! nRet 0x{0:x}", (uint32_t)nret);
        return false;
    }
	return true;
}

bool HikCACamera::initBrightness()
{
	if(nullptr == pDeviceHandle_)
	{
		return false;
	}
	spdlog::info("AAAAAA HikCACamera::initBrightness begin====");

	int nret = MV_CC_SetEnumValue(pDeviceHandle_,"FrameSpecInfoSelector",3);
	if(nret != MV_OK)
	{
		spdlog::error("set MV_CC_SetEnumValue fail!  BrightnessInfo nRet 0x{0:x}", (uint32_t)nret);
		return false;
	}

	
	nret = MV_CC_SetBoolValue(pDeviceHandle_,"FrameSpecInfo",true);
	if(nret != MV_OK)
	{
		spdlog::error("set FrameSpecInfo fail! nRet {0}", (uint32_t)nret);
		return false;
	}
	

	
	spdlog::info("HikCACamera::initBrightness end====");
	return true;
}



bool HikCACamera::stopGrabbing()
{
	if(nullptr == pDeviceHandle_)
	{
		return false;
	}

	return (MV_OK == MV_CC_StopGrabbing(pDeviceHandle_));
}


bool HikCACamera::closeDevice()
{

	if(nullptr == pDeviceHandle_)
	{
		return false;
	}
	
	int nRet = MV_OK;
	
    // close device
    nRet = MV_CC_CloseDevice(pDeviceHandle_);
    if (MV_OK != nRet)
    {
        spdlog::error("MV_CC_CloseDevice fail! nRet 0x{0:x}", (uint32_t)nRet);
        return false;
    }

    // 销毁句柄
    // destroy handle
    nRet = MV_CC_DestroyHandle(pDeviceHandle_);
    if (MV_OK != nRet)
    {
        spdlog::error("MV_CC_DestroyHandle fail! nRet 0x{0:x}", (uint32_t)nRet);
        return false;
    }
	pDeviceHandle_ = nullptr;
	return (MV_OK == nRet);
}


bool HikCACamera::getOneFrame(ImageBuffer*& imgBuffer)
{
	/*
	if(nullptr == imgBuffer)
	{
		return false;
	}
	*/

	if(payloadSize_ <= 0)
	{
		//
		return false;
	}

	MV_FRAME_OUT_INFO_EX stImageInfo;
    memset(&stImageInfo, 0, sizeof(MV_FRAME_OUT_INFO_EX));

	//从内存池里面拿
 	ImageBuffer* pImgBuffer = ImgBufferManager::instance().getBuffer();
	pImgBuffer->setlen(payloadSize_);

	int nRet = MV_CC_GetOneFrameTimeout(pDeviceHandle_, 
		pImgBuffer->getBuffer(), 
		pImgBuffer->getLen(),
		&stImageInfo, 
		1000);
	
	if (nRet == MV_OK)
    {
	    pImgBuffer->attribute_.width_   = stImageInfo.nWidth;
		pImgBuffer->attribute_.height_  = stImageInfo.nHeight;
		pImgBuffer->attribute_.averageBrightness_ = stImageInfo.nAverageBrightness;
		pImgBuffer->fromCamera_ = getIndex();

		imgBuffer = pImgBuffer;
        spdlog::info("GetOneFrame, Width{0}, Height{1}, nFrameNum{2},nAverageBrightness{3}\n", 
            stImageInfo.nWidth, stImageInfo.nHeight, stImageInfo.nFrameNum,stImageInfo.nAverageBrightness);
		return true;
    }
    else
	{
        spdlog::error("No data 0x{0:x}\n", (uint32_t)nRet);
		ImgBufferManager::instance().freeBuffer(pImgBuffer);
		return false;
    }
	
	return true;
}



