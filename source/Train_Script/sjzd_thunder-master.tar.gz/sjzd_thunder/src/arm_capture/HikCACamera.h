#ifndef SJZD_HIK_VISION_CAMERA
#define SJZD_HIK_VISION_CAMERA

#include "MyCamera.h"
#include "Thunder_Define.h"



class HikCACamera
	:public MyCamera{
	
public:
	HikCACamera(MV_CC_DEVICE_INFO*      pDeviceInfo);
	virtual ~HikCACamera();
	
	static int enumDevices(MV_CC_DEVICE_INFO_LIST* pstDevList);
	
public:
	bool openDevice();
	bool startGrabbing()      ;
	bool stopGrabbing()      ;
	bool closeDevice();
	bool getOneFrame(ImageBuffer*& imgBuffer);
	

private:
	bool initPayloadSize();
	bool initBrightness();
private:
	MV_CC_DEVICE_INFO*       pDeviceInfo_;
	void*                    pDeviceHandle_;
	unsigned int			 payloadSize_;
};


#endif



