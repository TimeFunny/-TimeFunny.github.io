#include "ImgBuffer.h"

ImageBuffer::ImageBuffer()
{
	
	bufLen_     = SJ_MAX_PAY_LOAD_SIZE;
	pbuf_       = (unsigned char *)malloc(sizeof(unsigned char) * bufLen_);
	fromCamera_ = -1;
}


ImageBuffer::~ImageBuffer()
{
	

}

unsigned char* ImageBuffer::getBuffer()
{
	return pbuf_;
}

unsigned int   ImageBuffer::getLen()
{
	return bufLen_;
}

void ImageBuffer::setlen(unsigned int len)
{
	bufLen_ = len;
}



ImageAttribute::ImageAttribute()
{
	averageBrightness_ = 0;
	width_             = 0;
	height_            = 0;
}

ImageAttribute::~ImageAttribute()
{
	
}


/*
ImageBufferManager::ImageBufferManager()
{
		
}

ImageBufferManager::~ImageBufferManager()
{
	
}
*/


