#include "ConfigFile.h"
#include "spdlog/spdlog.h"


ConfigFile::ConfigFile()
{
	fileName_                  = "config.xml";
	workMode_                  = "normal";
	cameraType_                = "usb_hikvision";
	cameraNum_                 = 4;
	preDetectQueSize_          = 25;
	brightDetectThreshold_     = 10;
	photoUpdateInter_          = 60;
	devicecId_                 = "deviceID";
	getFrameTimeout_           = 1000;
}

ConfigFile::~ConfigFile()
{

}

bool ConfigFile::readConfig()
{
	XMLDocument doc;
	if(doc.LoadFile(fileName_.c_str()) != 0)
	{
		spdlog::error("load xml failed,please check config file!");		
		return false;
	}
	
	XMLElement* root=doc.RootElement();
	if(NULL == root){
		return false;
	}
	
	spdlog::info("begin read config");		
	
	loadXmlStr(root,"workmode",workMode_);
	loadXmlStr(root,"cameratype",cameraType_);
	loadXmlShort(root,"cameranum",cameraNum_);
	

	/*
	node        = root->FirstChildElement("workmode");
    workMode_   = node->GetText();

	node        = root->FirstChildElement("cameranum");
	if(nullptr != node)
	{
		ptext       = node->GetText();
		if(nullptr != ptext)
		{
			cameraNum_ = (short)std::stoi(ptext);
		}
		
	}	
	
	node        = root->FirstChildElement("cameratype");
	if()
	cameraType_ = node->GetText();
	*/

	//printf("workmode is ptext:%s",ptext);
	spdlog::info("end read config");		
	return true;
}

void ConfigFile::loadXml()
{
	
}

void ConfigFile::loadXmlStr(XMLElement* ppNode,const char* nodeName,string& outVal)
{
	XMLElement* pNode  = ppNode->FirstChildElement(nodeName);
	if(nullptr != pNode)
	{
		const char* ptext = pNode->GetText();
		if(nullptr != ptext)
		{
			outVal = ptext;
		}
	}
   // workMode_   = node->GetText();
}

void ConfigFile::loadXmlInt(XMLElement* ppNode,const char* nodeName,int& outVal)
{
	XMLElement* pNode  = ppNode->FirstChildElement(nodeName);
	if(nullptr != pNode)
	{
		const char* ptext = pNode->GetText();
		if(nullptr != ptext)
		{
			outVal = (short)std::stoi(ptext);
		}
	}
}


void ConfigFile::loadXmlShort(XMLElement* ppNode,const char* nodeName,short& outVal)
{
	XMLElement* pNode  = ppNode->FirstChildElement(nodeName);
	if(nullptr != pNode)
	{
		const char* ptext = pNode->GetText();
		if(nullptr != ptext)
		{
			outVal = (short)std::stoi(ptext);
		}
	}
}




