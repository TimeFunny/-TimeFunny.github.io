#ifndef SJZD_CAMERA_MANAGER
#define SJZD_CAMERA_MANAGER

#include "MyCamera.h"
#include "common/Singleton.h"
#include "Thunder_Define.h"

class CameraManager{
public:
	CameraManager();
	virtual ~CameraManager();

	
public:
	bool init();
	bool openCameras();
	bool startGrabbing();
	bool stopGrabbing();
	bool closeCameras();
	void uninit();

	void copyCameras(vector<MyCamera*>& vecCameras);
private:
	bool checkDevices();
	bool initHikVisionDevices();

	void clearCameras();
private:
	vector<MyCamera*>   vecCamera_;
};

typedef   common::Singleton<CameraManager>      SingletonCameraManager;

#endif

