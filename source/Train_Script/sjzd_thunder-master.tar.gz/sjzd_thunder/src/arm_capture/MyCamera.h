#ifndef SJZD_MY_CAMERA
#define SJZD_MY_CAMERA
#include "ImgBuffer.h"
#include "common/MutexLock.h"
#include "Thunder_Define.h"
class MyCamera{

public:
	MyCamera();
	virtual ~MyCamera();
	
public:
	virtual bool openDevice()         = 0;
	virtual bool startGrabbing()      = 0;
	virtual bool stopGrabbing()       = 0;
	virtual bool closeDevice()        = 0;
	virtual bool getOneFrame(ImageBuffer*& imgBuffer)        = 0;
	short getIndex();
	void  setIndex(short index);

	
private:
	short 			index_;
};



#endif



