#ifndef SJZD_IMG_BUFFER
#define SJZD_IMG_BUFFER

#include "MemBufferManager.h"

class ImageAttribute{
public:
	ImageAttribute();
	~ImageAttribute();
public:
	int              averageBrightness_ ;
	int              width_             ;
	int              height_       ;
};


class ImageBuffer{
public: 
	ImageBuffer();
	virtual ~ImageBuffer();
	
public:
	unsigned char* getBuffer();
	unsigned int   getLen();

	void setlen(unsigned int len);
	
public:
	unsigned char*              pbuf_;
	unsigned int                bufLen_;
	//属于哪个相机
	unsigned short              fromCamera_;
	
	ImageAttribute              attribute_;

};



typedef common::Singleton<MEM_BUF_MANAGER<ImageBuffer>> ImgBufferManager;

/*
class ImageBufferManager{
public:
	ImageBufferManager();
	~ImageBufferManager();
public:
			
private:
	MemBufferManager<ImageBuffer> memImgBuffer_;
};
*/
#endif

